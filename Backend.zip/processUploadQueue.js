const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { v4: uuidv4 } = require('uuid');

// Initialize S3 client (use same config as in app.js)
const s3 = new S3Client({
  region: 'us-east-1',
  credentials: {
    accessKeyId: 'AKIAYGCAERWFXPQPCYVU',
    secretAccessKey: 'mN1Dr1ScxkYtif89knkwQvR1ZAwCHId6ip5XLZFC',
  },
});

// Example queue with one item (replace or populate as needed)
let uploadQueue = [
  {
    "folder": "input-lambda",
    "content": "Spark shuffle Error",
    "title": "Spark shuffle Error",
    "pipeline": "customer_support_etl"
  },
  {
    "folder": "input-lambda",
    "title": "load_to_warehouse task failed for Job customer_support_etl",
    "content": "Batch 4 upload failed during final commit phase [WarehouseCommitError] Write transaction could not be finalized. Error Code: WARE-9021",
    "pipeline": "customer_support_etl"
  },
  
  /* {
    "folder": "input-lambda",
    "content": "this is the new Error For Spark 2",
    "title": "Spark shuffle Error 2",
    "pipeline": "customer_support_etl"
  },
  {
    "folder": "input-lambda",
    "content": "this is the new Error For Spark 3",
    "title": "Spark shuffle Error 3",
    "pipeline": "customer_support_etl"
  },
  {
    "folder": "input-lambda",
    "content": "this is the new Error For Spark 4",
    "title": "Spark shuffle Error 4",
    "pipeline": "customer_support_etl"
  }, */
  {
    "folder": "input-lambda",
    "title": "load_to_warehouse task failed for Job payment_gateway_logs",
    "content": "abcdxxxxdefj cound't find",
    "pipeline": "payment_gateway_logs"
  }
];

// Function to process one upload from the queue
async function processUploadQueue() {
  if (uploadQueue.length === 0) {
    console.log('Upload queue is empty, nothing to process.');
    return;
  }

  const item = uploadQueue[0];

  const { folder, content, title, pipeline } = item;

  if (!content) {
    console.error('Skipping upload: content is required');
    uploadQueue.shift();
    return;
  }

  const fileUuid = uuidv4();

  const fileContent = JSON.stringify({
    queryId: fileUuid,
    question: content,
    title: title,
    timestamp: new Date().toISOString(),
    foundAnswer: false,
    status: 'processing',
    sla: 'TBD',
    job_name: pipeline,
  }, null, 2);

  const filename = `${fileUuid}.json`;
  const key = folder ? `${folder.replace(/\/+$/, '')}/${filename}` : filename;

  const params = {
    Bucket: 'hackathon-smart-incident-manager-final',
    Key: key,
    Body: fileContent,
    ContentType: 'application/json',
  };

  try {
    await s3.send(new PutObjectCommand(params));
    console.log(`File uploaded successfully from queue: ${key}`);
    uploadQueue.shift();
  } catch (error) {
    console.error('Error uploading file to S3 from queue:', error);
    uploadQueue.shift();
  }
}

// Run once immediately
/* processUploadQueue()
  .then(() => console.log('Processing done'))
  .catch(console.error); */

setInterval(() => {
  processUploadQueue();
}, 10 * 1000);