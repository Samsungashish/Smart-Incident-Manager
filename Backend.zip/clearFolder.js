const { S3Client, ListObjectsV2Command, DeleteObjectsCommand } = require('@aws-sdk/client-s3');
require('dotenv').config();

const s3 = new S3Client({
  region: 'us-east-1',
  credentials: {
    accessKeyId: 'AKIAYGCAERWFXPQPCYVU',
    secretAccessKey: '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',
  },
});

const bucketName = 'hackathon-smart-incident-manager-final';

async function clearFolder(prefix) {
  try {
    // List all objects with the given prefix
    const listParams = {
      Bucket: bucketName,
      Prefix: prefix,
    };

    const listedObjects = await s3.send(new ListObjectsV2Command(listParams));

    if (!listedObjects.Contents || listedObjects.Contents.length === 0) {
      console.log(`No objects found in folder: ${prefix}`);
      return;
    }

    // Prepare objects to delete
    const objectsToDelete = listedObjects.Contents.map(({ Key }) => ({ Key }));

    const deleteParams = {
      Bucket: bucketName,
      Delete: {
        Objects: objectsToDelete,
        Quiet: false,
      },
    };

    const deleteResult = await s3.send(new DeleteObjectsCommand(deleteParams));
    console.log(`Deleted objects from folder ${prefix}:`, deleteResult.Deleted);

    // If there are more objects (pagination), recursively delete them
    if (listedObjects.IsTruncated) {
      await clearFolder(prefix);
    }
  } catch (error) {
    console.error(`Error clearing folder ${prefix}:`, error);
  }
}

async function main() {
  console.log('Clearing input-lamda folder...');
  await clearFolder('input-lamda/');

  console.log('Clearing output-lamda folder...');
  await clearFolder('output-lamda/');

  console.log('Done clearing folders.');
}

main();
