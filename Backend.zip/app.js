const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { S3Client, PutObjectCommand, ListObjectsV2Command, GetObjectCommand } = require('@aws-sdk/client-s3');
require('dotenv').config();
const { v4: uuidv4 } = require('uuid');
const { Readable } = require('stream')
const { Buffer } = require('buffer')

const app = express();
const port = 4000;

app.use(cors());
app.use(express.json());

const jsonFilePath = path.join(path.resolve(), 'sample.json');

let clients = [];

// Helper to send events to all connected clients
function sendEventsToAll(newItems) {
  clients.forEach((res) => {
    res.write(`data: ${JSON.stringify(newItems)}\n\n`);
  });
}

// SSE endpoint
app.get('/api/read', (req, res) => {
  // Set headers for SSE
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });
  res.flushHeaders();

  // Read fresh data from sample.json synchronously
  try {
    const fileData = fs.readFileSync(jsonFilePath, 'utf8');
    const parsedData = JSON.parse(fileData);
    res.write(`data: ${JSON.stringify(parsedData)}\n\n`);
  } catch (err) {
    console.error('Error reading sample.json:', err);
    res.write(`data: ${JSON.stringify([])}\n\n`); // send empty array on error
  }

  // Add client to clients array
  clients.push(res);

  // Remove client when connection closes
  req.on('close', () => {
    clients = clients.filter((client) => client !== res);
  });
});

// Watch sample.json for changes
fs.watchFile(jsonFilePath, { interval: 1000 }, (curr, prev) => {
  if (curr.mtime !== prev.mtime) {
    try {
      const data = fs.readFileSync(jsonFilePath, 'utf8');
      const parsedData = JSON.parse(data);
      sendEventsToAll(parsedData);
    } catch (err) {
      console.error('Error reading sample.json on change:', err);
    }
  }
});

// POST endpoint to add an item and notify clients
app.post('/api/read', (req, res) => {
  const newData = req.body;

  try {
    // Read existing data synchronously
    const jsonString = fs.readFileSync(jsonFilePath, 'utf8');
    let dataArray = JSON.parse(jsonString);
    if (!Array.isArray(dataArray)) {
      dataArray = [];
    }

    // prepend new data
    dataArray.unshift(newData);

    // Write back to file asynchronously
    fs.writeFile(jsonFilePath, JSON.stringify(dataArray, null, 2), (writeErr) => {
      if (writeErr) {
        console.error('Error writing JSON file:', writeErr);
        return res.status(500).json({ error: 'Failed to save data' });
      }

      // Notify SSE clients with updated data
      sendEventsToAll(dataArray);

      res.status(201).json({ message: 'Data added successfully', data: newData });
    });
  } catch (err) {
    console.error('Error reading or parsing JSON file:', err);
    return res.status(500).json({ error: 'Failed to read or parse data' });
  }
});


// AWS Connection 

// Configure AWS S3 client
const s3 = new S3Client({
  region: 'us-east-1', // e.g. 'us-east-1'
  credentials: {
    accessKeyId: 'AKIAYGCAERWFXPQPCYVU',
    secretAccessKey: 'mN1Dr1ScxkYtif89knkwQvR1ZAwCHId6ip5XLZFC',
  },
});

app.listen(port, () => {
  console.log(`API server listening at http://localhost:${port}`);
});

// API endpoint to upload a .txt file to S3
app.post('/api/upload-txt', async (req, res) => {
  const { folder, content, title, pipeline } = req.body;

  if (!content) {
    return res.status(400).json({ error: 'content is required' });
  }

  // Generate UUID for filename and queryId
  const fileUuid = uuidv4();

  // Construct JSON content
  const fileContent = JSON.stringify({
    queryId: fileUuid,
    question: content,
    title: title,
    timestamp: new Date().toISOString(),
    foundAnswer: false, 
    status: 'processing',
    sla: 'TBD',
    job_name: pipeline
  }, null, 2);

  console.log("File Content:", fileContent)

  // Filename with .json extension
  const filename = `${fileUuid}.json`;

  // Construct the key with optional folder prefix
  const key = folder ? `${folder.replace(/\/+$/, '')}/${filename}` : filename;

  const params = {
    Bucket: 'hackathon-smart-incident-manager-final',
    Key: key,
    Body: fileContent,
    ContentType: 'application/json',
  };

  try {
    await s3.send(new PutObjectCommand(params));
    res.status(201).json({ message: 'File uploaded successfully', key });
  } catch (error) {
    console.error('Error uploading file to S3:', error);
    res.status(500).json({ error: 'Failed to upload file to S3' });
  }
});



app.get('/api/events', async (req, res) => {
  // Set headers for SSE
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  })
  res.flushHeaders()

  const bucketName = 'hackathon-smart-incident-manager-final'
  const prefix = 'output-lamda/' // folder inside the bucket

  try {
    // List all objects in the 'output/' folder
    const listCommand = new ListObjectsV2Command({
      Bucket: bucketName,
      Prefix: prefix,
    })
    const listResponse = await s3.send(listCommand)

    const contents = listResponse.Contents || []

    // Filter only .json files
    const jsonFiles = contents.filter((obj) => obj.Key && obj.Key.endsWith('.json'))

    // Helper to stream to string
    const streamToString = (stream) =>
      new Promise((resolve, reject) => {
        const chunks = []
        stream.on('data', (chunk) => chunks.push(chunk))
        stream.on('error', reject)
        stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
      })

    // Fetch and parse all JSON files concurrently
    const allData = await Promise.all(
      jsonFiles.map(async (file) => {
        const getCommand = new GetObjectCommand({
          Bucket: bucketName,
          Key: file.Key,
        })
        const data = await s3.send(getCommand)
        const bodyContents = await streamToString(data.Body)
        try {
          return JSON.parse(bodyContents)
        } catch (e) {
          console.error(`Error parsing JSON from file ${file.Key}:`, e)
          return null
        }
      })
    )

    // Filter out any nulls from parse errors
    const consolidatedData = allData.filter((item) => item !== null)

    // Send consolidated data as SSE event
    res.write(`data: ${JSON.stringify(consolidatedData)}\n\n`)
  } catch (err) {
    console.error('Error reading JSON files from S3:', err)
    res.write(`data: ${JSON.stringify([])}\n\n`) // send empty array on error
  }

  // Add client to clients array for future SSE updates if needed
  clients.push(res)

  // Remove client when connection closes
  req.on('close', () => {
    clients = clients.filter((client) => client !== res)
  })
})

app.post('/api/submitSolution', async (req, res) => {
  const { queryId, question, answer } = req.body;
  console.log('Received request to submit solution:', req.body);
  if (!queryId || !question || !answer) {
    return res.status(400).json({ error: 'queryId, question, and answer are required' });
  }

  // Construct JSON content
  const fileContent = JSON.stringify({
    queryId: queryId,
    question,
    answer,
    timestamp: new Date().toISOString(),
  }, null, 2);

  // Filename with .json extension using queryId
  const filename = `${queryId}.json`;

  // Key with folder prefix
  const key = `confluence_write/${filename}`;

  const params = {
    Bucket: 'hackathon-smart-incident-manager-final',
    Key: key,
    Body: fileContent,
    ContentType: 'application/json',
  };

  try {
    await s3.send(new PutObjectCommand(params));
    await updateSolutionFile(queryId, answer)
    res.status(201).json({ message: 'Solution submitted successfully', key });
  } catch (error) {
    console.error('Error uploading solution file to S3:', error);
    res.status(500).json({ error: 'Failed to upload solution file to S3' });
  }
});

const streamToString = async (stream) => {
    return await new Promise((resolve, reject) => {
        const chunks = []
        stream.on('data', (chunk) => chunks.push(chunk))
        stream.on('error', reject)
        stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')))
    })
}

async function updateSolutionFile(queryId, answer) {
  const bucket = 'hackathon-smart-incident-manager-final'
  const key = `output-lamda/${queryId}.json`

  let existingContent = {}
  try {
      const getObjectParams = { Bucket: bucket, Key: key }
      const data = await s3.send(new GetObjectCommand(getObjectParams))
      const bodyString = await streamToString(data.Body)
      console.log('Read from S3:', bodyString)
      existingContent = JSON.parse(bodyString)
  } catch (err) {
      if (err.name === 'NoSuchKey' || err.$metadata?.httpStatusCode === 404) {
          console.log('File not found, creating new one')
          existingContent = {}
      } else {
          console.error('Error reading from S3:', err)
          throw err
      }
  }

  existingContent.answer = answer;
  existingContent.foundAnswer = true;
  existingContent.status = 'SUCCESS';
  existingContent.runbook_url ='https://rahuljain20988.atlassian.net/wiki/spaces/PROJECTMAN/overview';
  

  const updatedJson = JSON.stringify(existingContent, null, 2)
  console.log('Uploading updated JSON:', updatedJson)

  const putObjectParams = {
      Bucket: bucket,
      Key: key,
      Body: updatedJson,
      ContentType: 'application/json',
  }

  try {
      await s3.send(new PutObjectCommand(putObjectParams))
      console.log('Successfully updated file in S3:', key)
  } catch (err) {
      console.error('Error writing to S3:', err)
      throw err
  }
}















